#include
http://s3.amazonaws.com/bobsgameserver/index_on_creation.sh
