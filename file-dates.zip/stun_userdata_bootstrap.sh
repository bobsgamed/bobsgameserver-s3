#include
http://s3.amazonaws.com/bobsgameserver/stun_on_creation.sh
