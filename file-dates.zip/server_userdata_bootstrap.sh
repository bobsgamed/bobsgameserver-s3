#include
http://s3.amazonaws.com/bobsgameserver/server_on_creation.sh
